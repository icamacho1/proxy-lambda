#! /usr/bin/python3
from proxy import Proxy
from typing import Any, Optional, Dict
from base64 import b64decode

# Class initialization:

class Lambda_handler:
	def __init__(self, event: Any):
		self.parameters = event.get("queryStringParameters", None)
		self.request_method = event["requestContext"]["http"]["method"]
		self.body = event.get("body", None)
		self.headers = event['headers']
		self.proxy = Proxy()
		self.params = self.parameters.get("params", None)
		self.headers = self.parameters.get("headers", None)

	def __get_url(self) -> Union[str,None]:
		url = this.parameters.get("url", None)
		if not url:
			return None
		url: str = b64decode(parameters['url'].encode()).decode()
		return url

	def __get_cookies(self) -> Union[Dict[str,str], None]:
		cookies = self.parameters.get("cookies", None)
		if cookies:
			decoded_cookies = b64decode(cookies.encode()).decode()
			return {cookie.split("=")[0]:"=".join(cookie.split("=")[1:]) for cookie in decoded_cookies.split(";")}
		return None

	def call_http_method(self) -> str:
		url = self.__get_url()
		if not url:
			return json.dumps({"status_code": 400, "json"})
		cookies = self.__get_cookies()
		response = proxy.execute(request_method=request_method, url=url, headers=self.headers, cookies=cookies, params=self.params, data=self.body)
		return response



def lambda_handler(event: Any, context: Optional[Any] = None) -> str:
	print(event)
	handler = Lambda_handler(event)
	response = handler.call_http_method()
	return response